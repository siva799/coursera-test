package com.tavant.searchAddress;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SearchAddressApplicationTests {

	@Test
	void contextLoads() {
	}

}
