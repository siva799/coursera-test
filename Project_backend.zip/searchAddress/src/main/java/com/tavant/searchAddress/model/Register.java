package com.tavant.searchAddress.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "register")
public class Register {
	
	@NotBlank(message = "Name should not be blank")
	private String Name;
	@Id
	@NotBlank(message = "Email should not be blank")
	@Email(message = "Email should be valid")
	private String email;
	@Max(20)
	@Min(6)
	@NotNull
	private String password;
	@Max(20)
	@Min(6)
	@NotNull
	private Integer password2;

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getPassword2() {
		return password2;
	}

	public void setPassword2(Integer password2) {
		this.password2 = password2;
	}

}
