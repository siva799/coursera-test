package com.tavant.searchAddress;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SearchAddressApplication {

	public static void main(String[] args) {
		SpringApplication.run(SearchAddressApplication.class, args);
	}

}
