package com.tavant.searchAddress.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tavant.searchAddress.exceptions.AccountNotExistsException;
import com.tavant.searchAddress.exceptions.PasswordNotMatchException;
import com.tavant.searchAddress.model.Register;
import com.tavant.searchAddress.repository.RegisterRepository;

@RestController
@RequestMapping("/api/register")
public class RegisterController {
	
	@Autowired
	RegisterRepository registerRepository;
	
	@GetMapping
	public String getAccount() {
		return "hello from register";
	}
	
	
	@PostMapping("/add")
	public Register addAccount( @RequestBody @Valid Register account)
			throws PasswordNotMatchException {
		if(account.getPassword().equals(account.getPassword2())) {
			throw new PasswordNotMatchException("password does not match");
		}
		else {
			return registerRepository.save(account);
		}
	}
	
	@GetMapping("/{email}")
	public ResponseEntity<?> getAccountByEmail(@PathVariable("email") String email)
			throws AccountNotExistsException {
		
		Optional<Register> optional = registerRepository.findById(email);
		
		if(optional.isPresent()) {
			return ResponseEntity.ok(optional.get());
		}
		else {
			
			throw new AccountNotExistsException("No Account Found with this Account");
		}
	}
	
	
	@PutMapping("/{email}")
	public ResponseEntity<?> updateaccount(@PathVariable (value = "email") 
	String email,@RequestBody Register account) throws AccountNotExistsException{
		Register account1=registerRepository.findById(email).
				orElseThrow(()->new AccountNotExistsException("No Account found with this mail"));
		
		final Register updatedaccount = registerRepository.save(account1);
		return ResponseEntity.ok(updatedaccount);
	}
	
	@DeleteMapping("/{email}")
	public Map<String,Boolean> deleteticket(@PathVariable(value = "email") String email)
	throws AccountNotExistsException{
		Register account1=registerRepository.findById(email).
				orElseThrow(()->new AccountNotExistsException("no account found for deletion"));
		
		registerRepository.delete(account1);
		
		Map<String,Boolean> response=new HashMap<>();
		response.put("deleted",Boolean.TRUE);
		return response;

	}
	

}
